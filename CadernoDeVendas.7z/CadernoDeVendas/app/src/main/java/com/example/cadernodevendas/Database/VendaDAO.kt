package com.example.cadernodevendas.Database

import android.content.ContentValues
import com.example.cadernodevendas.Models.Venda

class VendaDAO(databaseHandler: DatabaseHandler){

    val databaseHandler = databaseHandler

    fun add(venda: Venda): Boolean {
        val db = databaseHandler.writableDatabase
        val values = ContentValues()
        values.put(ARTESA, venda.artesa)
        values.put(QTD, venda.qtd)
        values.put(PRODUTO, venda.produto)
        values.put(VALOR, venda.valor)
        values.put(CARTAO, venda.cartao)
        values.put(PAGAMENTO, venda.pagamento)
        val _success = db.insert(TABLE_NAME, null, values)
        db.close()
        return (Integer.parseInt("$_success") != -1)
    }

    fun get(_id: Int): Venda? {
        var venda:Venda? = null
        val db = databaseHandler.writableDatabase
        val selectQuery = "SELECT  * FROM $TABLE_NAME WHERE $ID = $_id"
        val cursor = db.rawQuery(selectQuery, null)
        if (cursor != null) {
            cursor.moveToFirst()
            while (cursor.moveToNext()) {
                venda = Venda(cursor.getString(cursor.getColumnIndex(ID)).toInt(),
                    cursor.getString(cursor.getColumnIndex(ARTESA)),
                    cursor.getString(cursor.getColumnIndex(QTD)).toInt(),
                    cursor.getString(cursor.getColumnIndex(PRODUTO)),
                    cursor.getString(cursor.getColumnIndex(VALOR)).toDouble(),
                    cursor.getString(cursor.getColumnIndex(CARTAO)),
                    cursor.getString(cursor.getColumnIndex(PAGAMENTO))
                )
            }
        }
        cursor.close()
        return venda
    }

    fun all():List<Venda> {
        val vendaList = ArrayList<Venda>()
        val db = databaseHandler.writableDatabase
        val selectQuery = "SELECT  * FROM $TABLE_NAME"
        val cursor = db.rawQuery(selectQuery, null)
        if (cursor != null) {
            cursor.moveToFirst()
            while (cursor.moveToNext()) {
                val venda = Venda(cursor.getString(cursor.getColumnIndex(ID)).toInt(),
                cursor.getString(cursor.getColumnIndex(ARTESA)),
                cursor.getString(cursor.getColumnIndex(QTD)).toInt(),
                cursor.getString(cursor.getColumnIndex(PRODUTO)),
                cursor.getString(cursor.getColumnIndex(VALOR)).toDouble(),
                cursor.getString(cursor.getColumnIndex(CARTAO)),
                cursor.getString(cursor.getColumnIndex(PAGAMENTO))
                )
                vendaList.add(venda)
            }
        }
        cursor.close()
        return vendaList
    }

    fun update(venda: Venda): Boolean {
        val db = databaseHandler.writableDatabase
        val values = ContentValues()
        values.put(ARTESA, venda.artesa)
        values.put(QTD, venda.qtd)
        values.put(PRODUTO, venda.produto)
        values.put(VALOR, venda.valor)
        values.put(CARTAO, venda.cartao)
        values.put(PAGAMENTO, venda.pagamento)
        val _success = db.update(TABLE_NAME, values, ID + "=?", arrayOf(venda.id.toString())).toLong()
        db.close()
        return Integer.parseInt("$_success") != -1
    }

    fun delete(_id: Int): Boolean {
        val db = databaseHandler.writableDatabase
        val _success = db.delete(TABLE_NAME, ID + "=?", arrayOf(_id.toString())).toLong()
        db.close()
        return Integer.parseInt("$_success") != -1
    }

    companion object {
        private val TABLE_NAME = "Venda"
        private val ID = "Id"
        private val ARTESA = "Artesa"
        private val QTD = "QTD"
        private val PRODUTO = "Produto"
        private val VALOR = "Valor"
        private val CARTAO = "Cartao"
        private val PAGAMENTO = "Pagamento"
    }
}