package com.example.cadernodevendas.Others

import android.content.Context
import android.content.Intent
import android.support.v4.content.ContextCompat.startActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView
import com.example.cadernodevendas.EditActivity
import com.example.cadernodevendas.Models.Venda
import com.example.cadernodevendas.R

class VendaAdapter(private val context: Context,
                    private val dataSource: List<Venda>) : BaseAdapter() {

    private val inflater: LayoutInflater
            = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    //1
    override fun getCount(): Int {
        return dataSource.size
    }

    //2
    override fun getItem(position: Int): Any {
        return dataSource[position]
    }

    //3
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    //4
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        // Get view for row item
        val rowView = inflater.inflate(R.layout.venda_item, parent, false)

        // Get title element
        val produto = rowView.findViewById(R.id.produtoTxt) as TextView

// Get subtitle element
        val preco = rowView.findViewById(R.id.precoTxt) as TextView

        val editar = rowView.findViewById(R.id.editarBtn) as Button
        editar.setOnClickListener {
            edit(position)
        }
        // 1
        val venda = getItem(position) as Venda

// 2
        produto.text = venda.produto
        preco.text = venda.total().toString()

        return rowView
    }

    fun edit(id:Int){
        val intent = Intent(this.context,EditActivity::class.java)
        intent.putExtra("id",id)
        this.context.startActivity(intent)
    }

}