package com.example.cadernodevendas

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.TextView
import com.example.cadernodevendas.Database.DatabaseHandler
import com.example.cadernodevendas.Database.VendaDAO
import com.example.cadernodevendas.Models.Venda
import java.lang.Exception

class EditActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        populateForm()
    }

    fun populateForm(){
        val vendaDAO = VendaDAO(DatabaseHandler(this))
        val produto = findViewById<TextView>(R.id.produtoTxt) as TextView
        val artesa = findViewById<TextView>(R.id.artesaTxt) as TextView
        val qtd = findViewById<TextView>(R.id.qtdTxt) as TextView
        val valor = findViewById<TextView>(R.id.valorTxt) as TextView
        val cartao = findViewById<TextView>(R.id.cartaoTxt) as TextView
        val pagamento = findViewById<TextView>(R.id.pagamentoTxt) as TextView
        val venda = vendaDAO.get(intent.getIntExtra("id",0))
        try {
            produto.text = venda?.produto
            artesa.text = venda?.artesa
            qtd.text = venda?.qtd.toString()
            valor.text = venda?.valor.toString()
            cartao.text = venda?.cartao
            pagamento.text = venda?.pagamento
        }catch(e:Exception){
            System.out.println(e)
        }
    }

    fun edit(view:View){
        val vendaDAO = VendaDAO(DatabaseHandler(this))
        val produto = findViewById<TextView>(R.id.produtoTxt).text.toString()
        val artesa = findViewById<TextView>(R.id.artesaTxt).text.toString()
        val qtd = findViewById<TextView>(R.id.qtdTxt).text.toString().toInt()
        val valor = findViewById<TextView>(R.id.valorTxt).text.toString().toDouble()
        val cartao = findViewById<TextView>(R.id.cartaoTxt).text.toString()
        val pagamento = findViewById<TextView>(R.id.pagamentoTxt).text.toString()
        val venda = Venda(0,artesa,qtd,produto,valor,cartao,pagamento)
        vendaDAO.update(venda)
    }

    fun delete(view:View){
        val vendaDAO = VendaDAO(DatabaseHandler(this))
        vendaDAO.delete(0)
    }

    fun cancelar(view:View){
        finish()
    }
}