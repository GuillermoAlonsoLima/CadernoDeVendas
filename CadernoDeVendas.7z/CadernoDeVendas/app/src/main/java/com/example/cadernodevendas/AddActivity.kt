package com.example.cadernodevendas

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.ListView
import android.widget.TextView
import com.example.cadernodevendas.Database.DatabaseHandler
import com.example.cadernodevendas.Database.VendaDAO
import com.example.cadernodevendas.Models.Venda

class AddActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
    }

    fun add(view:View){
        val vendaDAO = VendaDAO(DatabaseHandler(this))
        val produto = findViewById<TextView>(R.id.produtoTxt).text.toString()
        val artesa = findViewById<TextView>(R.id.artesaTxt).text.toString()
        val qtd = findViewById<TextView>(R.id.qtdTxt).text.toString().toInt()
        val valor = findViewById<TextView>(R.id.valorTxt).text.toString().toDouble()
        val cartao = findViewById<TextView>(R.id.cartaoTxt).text.toString()
        val pagamento = findViewById<TextView>(R.id.pagamentoTxt).text.toString()
        val venda = Venda(0,artesa,qtd,produto,valor,cartao,pagamento)

        vendaDAO.add(venda)
    }

    fun cancelar(view:View){
        finish()
    }

}