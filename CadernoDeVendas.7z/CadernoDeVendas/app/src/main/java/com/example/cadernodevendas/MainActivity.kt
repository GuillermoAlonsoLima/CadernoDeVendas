package com.example.cadernodevendas

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.example.cadernodevendas.Database.DatabaseHandler
import com.example.cadernodevendas.Database.VendaDAO
import com.example.cadernodevendas.Models.Venda
import com.example.cadernodevendas.Others.VendaAdapter
import android.content.Intent
import android.view.View


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        populateList()
    }

    fun populateList(){
        val vendaDAO = VendaDAO(DatabaseHandler(this))
        val listView = findViewById<ListView>(R.id.vendasLv)
        val listItems = vendaDAO.all()
        val adapter = VendaAdapter(this, listItems)
        listView.adapter = adapter
    }

    fun add(view: View){
        val i = Intent(this@MainActivity, AddActivity::class.java)
        startActivity(i);
    }
}
