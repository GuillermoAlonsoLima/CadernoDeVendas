package com.example.cadernodevendas.Database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHandler(context: Context) : SQLiteOpenHelper(context, DatabaseHandler.DB_NAME, null, DatabaseHandler.DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
//        val DROP_TABLE_VENDA = "DROP TABLE IF EXISTS " + TABLE_NAME_VENDA
//        db.execSQL(DROP_TABLE_VENDA)
        val CREATE_TABLE_VENDA = "CREATE TABLE $TABLE_NAME_VENDA (" +
                ID + " INTEGER PRIMARY KEY," +
                ARTESA + " TEXT," + QTD + " INTEGER," +
                PRODUTO + " TEXT," + VALOR + " REAL,"+
                CARTAO + " TEXT, "+PAGAMENTO+ " TEXT );"
        db.execSQL(CREATE_TABLE_VENDA)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        val DROP_TABLE_VENDA = "DROP TABLE IF EXISTS " + TABLE_NAME_VENDA
        db.execSQL(DROP_TABLE_VENDA)
        onCreate(db)
    }

    companion object {

        private val DB_VERSION = 1
        private val DB_NAME = "CadernoDeVendas"
        private val TABLE_NAME_VENDA = "Venda"
        private val ID = "Id"
        private val ARTESA = "Artesa"
        private val QTD = "QTD"
        private val PRODUTO = "Produto"
        private val VALOR = "Valor"
        private val CARTAO = "Cartao"
        private val PAGAMENTO = "Pagamento"
    }
}
