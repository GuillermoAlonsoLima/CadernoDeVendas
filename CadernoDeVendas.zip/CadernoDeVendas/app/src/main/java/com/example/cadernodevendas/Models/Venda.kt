package com.example.cadernodevendas.Models

class Venda(id: Int, artesa: String, qtd: Int,produto:String, valor:Double,cartao:String,pagamento:String){
    var id = id
    var artesa = artesa
    var qtd = qtd
    var produto = produto
    var valor = valor
    var cartao = cartao
    var pagamento = pagamento

    fun total():Double{
        return qtd*valor
    }
}