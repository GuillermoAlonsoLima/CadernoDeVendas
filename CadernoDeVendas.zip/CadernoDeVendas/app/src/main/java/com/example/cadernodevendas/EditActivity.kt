package com.example.cadernodevendas

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.TextView
import com.example.cadernodevendas.Database.DatabaseHandler
import com.example.cadernodevendas.Database.VendaDAO
import com.example.cadernodevendas.Models.Venda
import java.lang.Exception

class EditActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        populateForm()
    }

    fun populateForm(){
        val vendaDAO = VendaDAO(DatabaseHandler(this))
        val produto = findViewById<TextView>(R.id.produtoTxt)
        val artesa = findViewById<TextView>(R.id.artesaTxt)
        val qtd = findViewById<TextView>(R.id.qtdTxt)
        val valor = findViewById<TextView>(R.id.valorTxt)
        val cartao = findViewById<TextView>(R.id.cartaoTxt)
        val pagamento = findViewById<TextView>(R.id.pagamentoTxt)
        val venda = vendaDAO.all().get(intent.getIntExtra("id",0)-2)
        Log.e("Venda",venda.toString())
        Log.e("id",intent.getIntExtra("id",0).toString())
        //try {
            produto.text = venda?.produto
            artesa.text = venda?.artesa
            qtd.text = venda?.qtd.toString()
            valor.text = venda?.valor.toString()
            cartao.text = venda?.cartao
            pagamento.text = venda?.pagamento
//        }catch(e:Exception){
//            System.out.println(e)
//        }
    }

    fun edit(view:View){
        val vendaDAO = VendaDAO(DatabaseHandler(this))
        val produto = findViewById<TextView>(R.id.produtoTxt).text.toString()
        val artesa = findViewById<TextView>(R.id.artesaTxt).text.toString()
        val qtd = findViewById<TextView>(R.id.qtdTxt).text.toString().toInt()
        val valor = findViewById<TextView>(R.id.valorTxt).text.toString().toDouble()
        val cartao = findViewById<TextView>(R.id.cartaoTxt).text.toString()
        val pagamento = findViewById<TextView>(R.id.pagamentoTxt).text.toString()
        val venda = Venda(intent.getIntExtra("id",0),artesa,qtd,produto,valor,cartao,pagamento)
        vendaDAO.update(venda)
        finish()
    }

    fun delete(view:View){
        val vendaDAO = VendaDAO(DatabaseHandler(this))
        vendaDAO.delete(intent.getIntExtra("id",0))
        finish()
    }

    fun cancelar(view:View){
        finish()
    }
}